...clear all
syms z 
fprintf('Transformada z inversa \n')
a = 2/z;
b = 2/(z-1);
c = -8/((2*z)-1);
d =  a+b+c;

e = iztrans (d); 

pretty (d)





