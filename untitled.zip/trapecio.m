%funcion de membresia TRIANGULAR

clear
clc
clf(figure(1))

disp("bienvenido a fm triangular");
conta = input("Ingrese la cantidad de FM Triangular");
xMin = input("ingrese x min");
xMax = input("ingrese x max");
conta2 = 0;

while conta2 < conta
    conta2 = conta2 + 1;
    disp("Trapecio num" + conta2);
    A = input("ingrese el parametro A de la fm: ");
    B = input("ingrese el parametro B de la fm: ");
    C = input("ingrese el parametro C de la fm: ");
    D = input("ingrese el parametro D de la fm: ");
    
    x= xMin : 0.1: xMax;
    y1= trapmf(x, [A B C D]);
    plot( x,y1 ,LineWidth=3, Color= [1 0 1] );
    hold on
    
    
end

grid
    title("funcion de membresia trapezoidal");
    xlabel("dominio de x");
    ylabel("u(x) pertenencia");