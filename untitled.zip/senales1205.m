...clear all
syms k T u z e a w n
fprintf('Transformada z de impulso dirac \n')
Tz1=ztrans(kroneckerDelta (k*T));

pretty (Tz1)
fprintf('Transformada z de escalon unitario \n') 
u (T)= 1
Tz2= ztrans (u(T)); 
pretty (Tz2)
fprintf('Transformada z de la función rampa \n') 

Rampa= k*T
Tz3 = ztrans (Rampa)
pretty (Tz3)

gt=cos(n*w*T)
Tz4=ztrans(gt)
pretty(Tz4)

LPGT=laplace(gt)
pretty(LPGT)

a=n+1
Tz5=ztrans(a)
pretty(Tz5)

parabola=n*n %% o 'n' al cuadrado
Tz6=ztrans(parabola)
pretty(Tz6)

