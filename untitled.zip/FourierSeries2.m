clc
% Construcci�n de funciones con la funci�n Heaviside "escalon unitario". Y
% luego se obtiene la serie de fourier
syms t;
x=heaviside(t+1)-2*heaviside(t)+heaviside(t-1);
ezplot(x,[-2,2]);
xlabel('t'),
ylabel('f(t)')
title('Funci�n heaviside')
grid on

syms t;
P=1; %semiperiodo
f=heaviside(t+0.5)-heaviside(t-0.5);
a=@(k) int(f*cos(k*pi*t/P),t,-P,P)/P;
b=@(k) int(f*sin(k*pi*t/P),t,-P,P)/P;
fs=a(0)/2;
for k=1:10 %n�mero de t�rminos
    fs=fs+a(k)*cos(k*pi*t/P)+b(k)*sin(k*pi*t/P);
end
pretty(fs)

% Ahora veamos un caso completo. Sea la funci�n peri�dica f(t)=t entre -1 y 1
% graficaremos y mostraremos la serie de fourier.
% Para estudiar otra funci�n peri�dica basta cambiar la definici�n de la 
% funci�n f y el valor de su semiperiodo P. Cambiando el valor de N 
% se muestran m�s o menos t�rminos del desarrollo en serie.
clc,clear all
syms t k P n;
assume(k,'Integer')
a = @(f,t,k,P) int(f*cos(k*pi*t/P),t,-P,P)/P
b = @(f,t,k,P) int(f*sin(k*pi*t/P),t,-P,P)/P
fs=@(f,t,n,P) a(f,t,0,P)/2+symsum(a(f,t,k,P)*cos(k*pi*t/P)+b(f,t,k,P)*sin(k*pi*t/P),k,1,n)

%definici�n de la fuerza y su semiperiodo P
f=2*t;
P=1;

N=30; %t�rminos del desarrollo en serie
pretty(fs(f,t,N,P));

hold on
ezplot(f,[-P P])
hg=ezplot(fs(f,t,N,P),[-P P]);
set(hg,'color','r')
hold off
xlabel('t')
ylabel('f(t)')
title('Serie de Fourier')

%arm�nicos
figure
k=1:N;
ak=a(f,t,k,P);
bk=b(f,t,k,P);
subplot(2,1,1)
stem(ak)
xlabel('k');
ylabel('a(k)')

subplot(2,1,2)
stem(bk)
xlabel('k');
ylabel('b(k)')

% En la gr�fica se representa la contribuci�n de los N=6 primeros arm�nicos 
% cada uno de los arm�nicos, en la parte superior los coeficientes ak, 
% y en la parte inferior los coeficientes bk. Por ser f(t)=t una funci�n impar, ak=0, 

% Segundo caso completo.

clc, clear all
syms t k P n;
assume(k,'Integer')
a = @(f,t,k,P) int(f*cos(k*pi*t/P),t,-P,P)/P;
b = @(f,t,k,P) int(f*sin(k*pi*t/P),t,-P,P)/P;
fs=@(f,t,n,P) a(f,t,0,P)/2+symsum(a(f,t,k,P)*cos(k*pi*t/P)+b(f,t,k,P)*sin(k*pi*t/P),k,1,n);

%definici�n de la fuerza y su semiperiodo P
f=t*(heaviside(t)-heaviside(t-pi/2))+(heaviside(t-pi/2)-heaviside(t-pi))*pi/2;
P=pi;

N=6; %t�rminos del desarrollo en serie
pretty(fs(f,t,N,P))
latex(fs(f,t,N,P))
hold on
ezplot(f,[-P P])
hg=ezplot(fs(f,t,N,P),[-P P]);
set(hg,'color','r')
set(gca,'XTick',-pi:pi/2:pi)
set(gca,'XTickLabel',{'-\pi','-\pi/2','0','\pi/2','\pi'})
set(gca,'YTick',0:pi/2:pi)
set(gca,'YTickLabel',{'0','\pi/2','\pi'})
hold off
grid on
xlabel('t')
ylabel('f(t)')
title('Serie de Fourier')

%arm�nicos
figure
k=1:N;
ak=a(f,t,k,P);
bk=b(f,t,k,P);
subplot(2,1,1)
stem(ak)
xlabel('k');
ylabel('a(k)')

subplot(2,1,2)
stem(bk)
xlabel('k');
ylabel('b(k)')

% Forma compleja pulso rectangular
% Se establece el n�mero n de t�rminos del desarrollo en serie.
% La semianchura a del pulso rectangular (menor que ?)
% Se dibuja la funci�n f(t) entre -? y +? en color azul y con ancho de l�nea 2.
% Se dibuja la aproximaci�n a la funci�n sumando n t�rminos del desarrollo en serie (positivos y negativos) en color rojo de anchura de l�nea 1.
% Tomar A=1

clc
a=1; %Semianchura del pulso rectangular a<pi
n=70; %n�mero de terminos
hold on
x=[-pi -a -a a a pi];
y=[0 0 1 1 0 0];
plot(x,y,'b','linewidth',1.5)
x=linspace(-pi,pi,100);
y=zeros(length(x),1);

for j=1:length(x)
    y(j)=0;
    for k=-n:n
        if k==0 
            y(j)=y(j)+a/pi;
        else
            y(j)=y(j)+sin(k*a)*exp(1i*k*x(j))/(k*pi);
        end
     end
end
%ejes
plot([-4 4],[0 0],'k')
plot([0 0],[-0.2 1.2],'k')
%serie de Fourier
plot(x,real(y),'r');
title(sprintf('Aproximaci�n de Fourier: %i t�rminos',n))
xlabel('t'); 
ylabel('f(t)')
grid on
hold off

% Ejemplo 2 cn la funci�n diente de sierra
% Se establece el n�mero n de t�rminos del desarrollo en serie.
% Se dibuja la funci�n f(t) entre -? y +? en color azul y con ancho de l�nea 2.
% Se dibuja la aproximaci�n a la funci�n sumando n t�rminos del desarrollo en serie (positivos y negativos) en color rojo de anchura de l�nea 1.
% Tomar A=1
clc
n=700; %N�mero de t�rminos
hold on
plot([-pi,pi],[-1 1],'b','linewidth',1.5)
x=linspace(-pi,pi,100);
y=zeros(length(x),1);
for j=1:length(x)
    y(j)=0;
    for k=-n:n
        y(j)=3/2+(6/(j*pi))*sin(j);
    end
end
%ejes
plot([-4 4],[0 0],'k')
plot([0 0],[-1.5 1.5],'k')
%serie de Fourier
plot(x,real(y), 'r');
title(sprintf('Aproximaci�n de Fourier: %i t�rminos',n))
grid on
xlabel('t'); 
ylabel('f(t)')
hold off