clc
clear all
%Ahora vamos a empezar a usar Fourier. 
% Pulso rectangular simétrico de anchura pi, 
% y periodo 2pi. Amplitud 3
% graficamos el resultado 7 términos:

n=11111;
hold on
%hold off
x=[0 0 pi pi 2*pi];
y=[0 3 3 0 0];
plot(x,y,'b','linewidth',1.5)
x=linspace(0,2*pi,100);
y=zeros(length(x),1);
for i=1:length(x)
    y(i)=3/2;
    for k=1:2:n
        y(i)=y(i)+6*sin(k*x(i))/(k*pi);
        seriefourier=y(i)
     end
end
plot(x,y, 'r');
title(sprintf('Aproximación de Fourier: %i términos',n))
xlabel('t'); 
ylabel('f(t)')
seriefourier
grid on
hold off

%Segunda serie de Fourier de un pulso rectangular
clc
clear all
n=10;
hold on
x=[-1 -0.5 -0.5 0.5 0.5 1];
y=[0 0 1 1 0 0];
plot(x,y,'b','linewidth',1.5)
x=linspace(-1,1,100);
y=zeros(length(x),1);
for i=1:length(x)
    y(i)=1/2;
    for k=1:2:n
        y(i)=y(i)+(-1)^((k-1)/2)*2*cos(k*pi*x(i))/(k*pi);
     end
end
plot(x,y, 'r');
title(sprintf('Aproximación de Fourier: %i términos',n))
xlabel('t'); 
ylabel('f(t)')
grid on
hold off
