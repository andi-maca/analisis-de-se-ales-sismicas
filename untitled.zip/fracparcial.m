syms n;
a = n+1;
b= 2/((z^2-z)*((2*z)-1)) ;

d =ztrans (b);
disp(d);
pretty (d);

e = iztrans (b); 
disp (e)
pretty(e);